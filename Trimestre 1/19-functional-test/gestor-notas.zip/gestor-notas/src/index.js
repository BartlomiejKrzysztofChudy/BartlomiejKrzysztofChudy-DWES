import { startApplication } from './app.js';

startApplication();
